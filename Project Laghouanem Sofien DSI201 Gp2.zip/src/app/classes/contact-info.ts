export interface ContactInfo {
    id:number;
    name: string;
    email: string;
    message: string;
}