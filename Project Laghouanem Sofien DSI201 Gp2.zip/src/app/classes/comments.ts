export interface Comment {
    id: number;
    productId: number;
    userId: number;
    text: string;
    date: string;
  }
  